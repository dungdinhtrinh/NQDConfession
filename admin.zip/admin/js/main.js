
$(document).ready(function(){
	if(window.innerWidth <= 575) alert('Hãy dùng màn hình ngang hoặc sử dụng máy tính (laptop) để nâng cao trải nghiệm quản lý!');
  	$('[data-toggle="tooltip"]').tooltip(); 
  	$(".dataConfess").click(function(){
  		let $this  =$(this);
  		let val = $this.text();
      let height = window.innerHeight;
  		$("body").css({'overflow-y' : 'hidden'}).append('<div class="bg"></div><div class="box" style="opacity:0"><textarea name="" id="" rows="1" style="max-height:  '+(height - 150)+' px">'+val+'</textarea></div>');
  		$("textarea").autoMoreTextarea();
  		$("textarea").attr('disabled','disabled');
  		$(".bg, .box").animate({'opacity' : '1'});
  		$(".bg").click(function(){
  			$(".bg, .box").animate({'opacity' : '0'});
  			$(".djsad").remove();
        $("body").css({'overflow-y' : 'auto'});
  			setTimeout(function(){
  				$(".bg,.box").remove();
  			},300);
  		});
  	});

    $(".copy").click(function(){
      let $this  =$(this);
      let val = $this.parents('tr').find('.dataConfess').text();
      $("body").append('<textarea name="" id="" rows="1">'+val+'</textarea>');
      $("textarea").select();
      document.execCommand("copy");
      $("textarea").remove();
    });
  	
  	$(".changActive").click(function(){
      
  		let $this = $(this);
  		let val = $this.text();
  		let id = $this.parents('tr').data('id');
      if(val=='Yes' && (typeof admin_access == "undefined" || admin_access == false)){
        return;
      }
  		$("body").append('<div class="bg"></div><div class="box text-center"><p>Bạn chắc chắn muốn đánh dấu post '+ (val == 'Yes' ? '<strong>chưa được</strong>' : '<strong>đã được</strong>') + ' đăng?</p><button class="btn btn-success ml-1 mr-1 access">Submit</button><button class="btn btn-danger ml-1 mr-1 cancel">Cancel</button></div></div>');
  		$(".bg").animate({'opacity' : '1'});
  		$(".bg, .cancel").click(function(){
  			$(".bg").animate({'opacity' : '0'});
  			$(".djsad").remove();
  			setTimeout(function(){
  				$(".bg,.box").remove();
  			},300);
  			return;
  		});
  		$(".access").click(function(){
			$.ajax({
	            url : "./changActive.php",
	            type : "post",
	            data : {
	                 id : id
	            },
	            success : function (result){
	                let outResult = JSON.parse(result);
	                if(outResult.code == '1'){
	                	$this.text(outResult.mess);
                    if(typeof admin_access == "undefined" || admin_access == false){
                      $this.removeClass('btn-success').addClass('btn-secondary').attr('disabled','disabled');
                    }
	                }
	                else{
	                	$("table").after('<div class="alert alert-danger">'+outResult.mess+'</div>');
	                }
	            }
	        });
	        $(".bg").click();
  		});
  	});

    $(".user").click(function(){
      $(".nav-user").toggleClass('active');
      return false;
    });
    $(".changePass").click(function(){
      var name = $(this).data('name');
      $("body").append('<div class="bg"></div><div class="box text-center form-change-pass"><div class="form-group"><label for="old-password">Old Password:</label><input type="password" class="form-control text-center old-password"></div><div class="form-group"><label for="new-password">Password:</label><input type="password" class="form-control text-center new-password"></div><div class="form-group"><label for="re-new-password">Repassword:</label><input type="password" class="form-control text-center re-new-password"></div><button class="btn btn-success ml-1 mr-1 access">Submit</button><button class="btn btn-danger ml-1 mr-1 cancel">Cancel</button></div></div>');
      $(".bg").animate({'opacity' : '1'});
      $(".cancel").click(function(){
        $(".bg").animate({'opacity' : '0'});
        setTimeout(function(){
          $(".bg,.box").remove();
        },300);
        return;
      });
      $(".old-password, .new-password,.re-new-password").focus(function(){
        $(this).removeAttr('style');
      });
      $(".new-password, .re-new-password").on('keyup',function(){
        let $this = $(this);
        let val = $this.val();
        let else_class = $this.hasClass('new-password') ? 're-new-password' : 'new-password';
        $(".new-password, .re-new-password").removeAttr('style');
        if($('.' + else_class).val().trim() == '') return;
        if($('.' + else_class).val() == val){
          $(".new-password, .re-new-password").css({'border-color' : '#28a745'});
          return;
        }
      });
      $(".access").click(function(){
        if($(".old-password").val().trim() == ''){
          $(".old-password").css({'border-color' : '#db3545'});
          return;
        }
        if($(".new-password").val().trim() == ''){
          $(".new-password").css({'border-color' : '#db3545'});
          return;
        }
        if($(".re-new-password").val().trim() == ''){
          $(".re-new-password").css({'border-color' : '#db3545'});
          return;
        }
        if($(".new-password").val().trim() != $(".re-new-password").val().trim()){
          $(".new-password, .re-new-password").css({'border-color' : '#db3545'});
          return;
        }
        $.ajax({
              url : "./manage/changeUser.php",
              type : "post",
              data : {
                t : 'changePass',
                name : name,
                oldpass : $('.old-password').val().trim(),
                pass : $('.new-password').val().trim()
              },
              success : function (result){
                // console.log(result + '\n' + name);
                  let outResult = JSON.parse(result);
                  if(outResult.code == '1'){
                    $("main,.box").empty();
                    $(".box").append('<p style="color:#28a745;font-size:24px">'+outResult.mess+'</p><div class="text-center"><button class="btn btn-success" onclick="window.location.assign(\'./logout.php\');">Login</button></div>');
                    // window.location="./logout.php";
                  }
                  else if(outResult.code == '3'){
                    $(".old-password").css({'border-color' : '#db3545'}).before('<div class="alert alert-danger">'+outResult.mess+'</div>');
                  }
                  else if(outResult.code == '2'){
                    $(".box").empty().append(outResult.mess);
                  }
                  else{
                    $("main").append('<div class="alert alert-danger">'+outResult.mess+'</div>');
                  }
              }
          });
      });
      return false;
    });
    $(".changeVerify").click(function(){
      var name = $(this).data('name');
      var verify = act == '1' ? 'YES' : 'NO';
      $("body").append('<div class="bg"></div><div class="box text-center form-change-pass"><div class="form-group"><label for="email">Email:</label><input type="text" class="form-control text-center email" value="'+str+'"></div><div class="form-group mb-5"><label for="email" class="mr-3">Verify:</label><button class="btn btn-success changePassSubmit">'+verify+'</button></div><button class="btn btn-success ml-1 mr-1 access">Submit</button><button class="btn btn-danger ml-1 mr-1 cancel">Cancel</button></div>');
      $(".bg").animate({'opacity' : '1'});
      $(".cancel").click(function(){
        $(".bg").animate({'opacity' : '0'});
        setTimeout(function(){
          $(".bg,.box").remove();
        },300);
        return;
      });
      $(".email").focus(function(){
        $(this).removeAttr('style');
      });
      $(".access").click(function(){
        if($(".email").val().trim() == ''){
          $(".email").css({'border-color' : '#db3545'});
          return;
        }
        $.ajax({
              url : "./manage/changeUser.php",
              type : "post",
              data : {
                t : 'changeVerify',
                name : name,
                email : $('.email').val().trim(),
                verify : verify
              },
              success : function (result){
                // console.log(result + '\n' + name);
                  let outResult = JSON.parse(result);
                  if(outResult.code == '1'){
                    $("main,.box").empty();
                    $(".box").append('<p style="color:#28a745;font-size:24px">'+outResult.mess+'</p><div class="text-center"><button class="btn btn-success" onclick="window.location.assign(\'./logout.php\');">Login</button></div>');
                    // window.location="./logout.php";
                  }
                  else if(outResult.code == '3'){
                    $(".email").before('<div class="alert alert-danger">'+outResult.mess+'</div>');
                    $('.changePassSubmit').click();
                  }
                  else if(outResult.code == '2'){
                    $(".box").empty().append(outResult.mess);
                  }
                  else{
                    $("main").append('<div class="alert alert-danger">'+outResult.mess+'</div>');
                  }
              }
          });
      });
      $('.changePassSubmit').click(function(){
        verify = verify == 'YES' ? 'NO' : 'YES';
        $(this).text(verify);
      });
      return false;
    });

});

// <button type="submit" class="btn btn-primary">Submit</button>