<?php
	if(!isset($_SESSION)) session_start();

	if(!isset($_SESSION['logined']) || !isset($_SESSION['access'])){
		$_SESSION['login_first'] = 'Trước tiên hãy đãng nhập với tư cách admin!';
		header('Location: ../login');
	}

	if(!isset($_POST) && $_SESSION['access'] != 'admin'){
		$_SESSION['access_error'] = "Bạn không đủ quyền truy cập trang quản trị tối cao!";
		header('Location: ../');
	}

	if(isset($_POST)){
		include '../../config/config.php';

		if(!isset($_POST['t'])){
			$_SESSION['access_error'] = "Bạn không đủ quyền truy cập trang quản trị tối cao!";
			header('Location: ../');
		}

		if($_POST['t'] == 'add' || $_POST['t'] == 'edit'){
			if($_POST['t'] == 'edit') $id = $_POST['id'];
			$username = $_POST['username'];
			$password = $_POST['password'];
			$access = $_POST['access'] == '1' ? 'admin' : 'supporter';
			$nowdate = date('d/m/Y');
			$time = $_POST['time'] == '' ? $nowdate : $_POST['time'].' '.$nowdate;
			$sql = "SELECT * FROM account WHERE username = '".$username."'";
			$result = mysqli_query($conn, $sql);
			if($_POST['t'] == 'add' && mysqli_num_rows($result) != 0){
	        	echo json_encode(array('code' => '0', 'mess' => 'Username đã tồn tại!'));
	        	exit();
	        }
	        if($_POST['t'] == 'add'){
	        	$sql_insert = "INSERT INTO account (username, password, access, time_create) VALUES ('".$username."', '".$password."','".$access."', '".$time."')";
	        }
	        else if($_POST['t'] == 'edit'){
	        	$sql_insert = "UPDATE account SET username='".$username."', password='".$password."', time_create='".$time."', access='".$access."' WHERE id=".$id."";
	        	// echo json_encode(array('code' => '0', 'mess' => $sql_insert));
	        	// exit();
	        }
	        else{
	        	echo json_encode(array('code' => '0', 'mess' => 'Lệnh truy vấn không chính xác!'));
	        	exit();
	        }
	        if (mysqli_query($conn, $sql_insert)) {
			     echo json_encode(array('code' => '1', 'mess' => 'Done!'));
			}
			else {
			    echo json_encode(array('code' => '0', 'mess' => 'Into Sql Error!'));
			}
		}
		else if($_POST['t'] == 'del'){
			$id = $_POST['id'];
			$admin = $_POST['admin'];
			$sql = "SELECT * FROM account WHERE id = '".$id."'";
			$result = mysqli_query($conn, $sql);
			if(mysqli_num_rows($result) <= 0){
	        	echo json_encode(array('code' => '0', 'mess' => 'Username không tồn tại!'));
	        	exit();
	        }
	        if($admin == '1'){
	        	$sql_admin = "SELECT * FROM account WHERE access = 'admin'";
				$result_admin = mysqli_query($conn, $sql_admin);
				if(mysqli_num_rows($result_admin) <= 1){
		        	echo json_encode(array('code' => '0', 'mess' => 'Bạn là admin duy nhất. Một nước không thể không vua. Hãy kiếm người kế vị trước khi thoái vị!'));
		        	exit();
		        }
	        }
	        else{
	        	$sql_delete = "DELETE FROM account WHERE id = ".$id;
            	if (mysqli_query($conn, $sql_delete)) {
        		    echo json_encode(['code' => '1', 'mess' => 'Done!']);
        		} else {
        		    echo json_encode(['code' => '0', 'mess' => 'Error Change This User from Database!']);
        		}
	        }
		}
		else if($_POST['t'] == 'changeAccess' || $_POST['t'] == 'changeActive'){
			$id = $_POST['id'];
			$admin = $_POST['admin'];
			if($_POST['t'] == 'changeAccess'){
				$val = $_POST['val'] == '1' ? 'admin' : 'supporter';
			}
			else if($_POST['t'] == 'changeActive'){
				$val = $_POST['val'] == '1' ? '0' : '1';
			}
			$sql = "SELECT * FROM account WHERE id = '".$id."'";
			$result = mysqli_query($conn, $sql);
			if(mysqli_num_rows($result) <= 0){
	        	echo json_encode(array('code' => '0', 'mess' => 'Username không tồn tại!'));
	        	exit();
	        }
	        if($admin == '1'){
	        	$sql_admin = "SELECT * FROM account WHERE access = 'admin'";
				$result_admin = mysqli_query($conn, $sql_admin);
				if(mysqli_num_rows($result_admin) <= 1){
		        	echo json_encode(array('code' => '0', 'mess' => 'Bạn là admin duy nhất. Một nước không thể không vua. Hãy kiếm người kế vị trước khi thoái vị!'));
		        	exit();
		        }
	        }
        	if($_POST['t'] == 'changeAccess'){
	        	$sql_update = "UPDATE account SET access='".$val."' WHERE id=".$id."";
	        	// echo json_encode(array('code' => '0', 'mess' => $sql_update));
	        	// exit();
	        }
	        else if($_POST['t'] == 'changeActive'){
	        	$sql_update = "UPDATE account SET active='".$val."' WHERE id=".$id."";
	        	// echo json_encode(array('code' => '0', 'mess' => $sql_update));
	        	// exit();
	        }
        	if (mysqli_query($conn, $sql_update)) {
    		    echo json_encode(['code' => '1', 'mess' => 'Done!']);
    		} else {
    		    echo json_encode(['code' => '0', 'mess' => 'Error Change This User from Database!']);
    		}
		}
		else if($_POST['t'] == 'changePass'){
			$name = $_POST['name'];
			$oldpass = $_POST['oldpass'];
			$pass = $_POST['pass'];
			if($name == '' || $pass == ''){
				echo json_encode(array('code' => '0', 'mess' => 'Username or password not define!'));
	        	exit();
			}
			$sql = "SELECT password FROM account WHERE username = '".$name."'";
			// echo $sql.' '.$name.' '.$pass.' ';
			$result = mysqli_query($conn, $sql);
			if(mysqli_num_rows($result) <= 0){
	        	echo json_encode(array('code' => '0', 'mess' => 'Username không tồn tại!'));
	        	exit();
	        }
	        else{
	        	while($row = mysqli_fetch_assoc($result)) {
	        		if($oldpass != $row['password']){
	        			echo json_encode(array('code' => '3', 'mess' => 'Mật khẩu cũ không chính xác!'));
	        			exit();
	        		}
	        	}
	        }
	        $sql_update = "UPDATE account SET password='".$pass."' WHERE username='".$name."'";
	        if (mysqli_query($conn, $sql_update)) {
    		    echo json_encode(['code' => '1', 'mess' => 'Done!']);
    		    exit();
    		}
    		else {
    		    echo json_encode(['code' => '0', 'mess' => 'Error Change This User from Database!']);
    		    exit();
    		}
    		echo json_encode(['code' => '2', 'mess' => 'Lỗi hệ thống! Vui lòng liên hệ Admin để sửa lỗi!']);
    		exit();
		}
		else if($_POST['t'] == 'changeVerify'){
			$name = $_POST['name'];
			$email = $_POST['email'];
			$verify = $_POST['verify'] == 'YES' ? '1' : '0';
			if($email == ''){
				echo json_encode(array('code' => '0', 'mess' => 'Username or password not define!'));
	        	exit();
			}
			$sql = "SELECT access FROM account WHERE username = '".$name."'";
			$result = mysqli_query($conn, $sql);
			if(mysqli_num_rows($result) <= 0){
	        	echo json_encode(array('code' => '0', 'mess' => 'Username không tồn tại!'));
	        	exit();
	        }
	        else{
	        	while($row = mysqli_fetch_assoc($result)) {
	        		if($row['access'] == 'admin' && $verify == '0'){
	        			echo json_encode(array('code' => '3', 'mess' => 'Tài khoản admin bắt buộc verify!'));
	        			exit();
	        		}
	        	}
	        }
	        $sql_update = "UPDATE account SET email='".$email."', verify='".$verify."' WHERE username='".$name."'";
	        if (mysqli_query($conn, $sql_update)) {
    		    echo json_encode(['code' => '1', 'mess' => 'Thay đổi đã được lưu! Hãy đăng nhập lại']);
    		    exit();
    		}
    		else {
    		    echo json_encode(['code' => '0', 'mess' => 'Error Change This User from Database!']);
    		    exit();
    		}
    		echo json_encode(['code' => '2', 'mess' => 'Lỗi hệ thống! Vui lòng liên hệ Admin để sửa lỗi!']);
    		exit();
		}
		else{
			echo json_encode(['code' => '2', 'mess' => 'Lỗi hệ thống! Vui lòng liên hệ Admin để sửa lỗi!']);
    		exit();
		}
	}
?>