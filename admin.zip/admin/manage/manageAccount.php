<?php
if (!isset($_SESSION)) {
    session_start();
}

function r_star($n){
  $return = '';
  for($i =0; $i<$n;$i++){
    $return = $return.'*';
  }
  return $return;
}

function r_pass(){
  return r_star(rand(4,10));
}

?>
<?php
	include '../../config/config.php';

    $arr = [];
    $i = 1;

    $sql = "SELECT * FROM account";
    $result = mysqli_query($conn, $sql);
    if (mysqli_num_rows($result) > 0){
    	while($row = mysqli_fetch_assoc($result)) {
            if($row['saoxa37'] == '0'){
                $timeadd = $row['time_create'] == '' ? 'Null' : $row['time_create'];
                $active = $row['active'] == '1' ? 'Access' : 'Block';
                $add = ['id' => $row['id'], 'stt' => $i++, 'username' => $row['username'], 'email' => $row['email'] ,'active' => $active,'active_val' => $row['active'],'access' => $row['access'],'time' => $timeadd];
                $arr[] = $add;
            }
	    }
    }
    echo '<script>let thisname = "'.$_SESSION['logined'].'";</script>';
?>

<!DOCTYPE html>
<html lang="vi">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>NQDConfessions</title>
    <link rel="shortcut icon" href="https://i.imgur.com/mmfPu9T.png">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link href="https://fonts.googleapis.com/css?family=Roboto+Slab&display=swap" rel="stylesheet">
	<link rel="stylesheet" href="../css/dashboard.css">
	<link rel="stylesheet" href="../css/manageAccount.css">
</head>
<body>

	<body>
    <nav class="navbar navbar-dark sticky-top bg-dark flex-md-nowrap p-0">
      <a class="navbar-brand col-8 col-sm-3 col-md-2 mr-0 font-weight-bold" href="../../">NQDConfessions</a>
      <ul class="navbar-nav px-3">
        <li class="nav-item text-nowrap">
          <a class="nav-link" href="../logout.php">Logout</a>
        </li>
      </ul>
    </nav>

    <div class="container-fluid">
      <div class="row">
        <nav class="col-md-2 d-none d-md-block bg-light sidebar">
          <div class="sidebar-sticky">
            <ul class="nav flex-column">
              <li class="nav-item">
                <a class="nav-link" href="../">Admin</a>
              </li>
              <li class="nav-item">
                <a class="nav-link active" href="./">Manage Account</a>
              </li>
            </ul>
          </div>
        </nav>

        <main role="main" class="col-md-10 ml-sm-auto col-lg-10 pt-3 px-4">
          <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pb-2 mb-3 border-bottom">
            <nav aria-label="breadcrumb" class="w-100">
			  <ol class="breadcrumb">
			    <li class="breadcrumb-item"><a href="../">Admin</a></li>
			    <li class="breadcrumb-item active" aria-current="page">Manage Account</li>
			  </ol>
			</nav>
          </div>

          <h2>Manage Account <a href="./?page=add" class="float-right add-new">Add new</a></h2>
          <div class="table-responsive">
            <table class="table table-striped table-sm">
              <thead>
                <tr>
                  <th>STT</th>
                  <th>Username</th>
                  <th>Email</th>
                  <th>Access</th>
                  <th>Time Create</th>
                  <th>Active</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
              	<?php
              	if(count($arr) == 0){
              		echo '<tr><td colspan="6" align="center"><div class="alert alert-primary">No Account</div></td></tr>';
              	}
              	foreach ($arr as $a) {
                  echo '<tr data-id="'.$a['id'].'"><td>'.$a['stt'].'</td><td class="name-user">'.$a['username'].'</td><td>'.$a['email'].'</td><td><select class="btn btn-secondary changeAccess" data-id="'.$a['id'].'" data-name="'.$a['username'].'" ><option value="1" ';
              	   // if($a['access'] == 'admin') echo 'selected="selected"'; 
                  echo '>Admin</option><option value="2" ';
                   if($a['access'] == 'supporter') echo 'selected="selected"'; 
                  echo '>Supporter</option></select></td><td>'.$a['time'].'</td><td><button data-id="'.$a['id'].'" class="btn btn-success changeActive" data-act="'.$a['active_val'].'" data-name="'.$a['username'].'" >'.$a['active'].'</button></td><td><button class="btn btn-danger delete">Del</button></td></tr>';
                }
              	?>
              </tbody>
            </table>
          </div>
        </main>
      </div>
    </div>

	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
	<script src="../js/autoMoreTextarea.js"></script>
  <script>
    $(document).ready(function(){
      $(".delete").click(function(){
        let $this = $(this);
        let admin = '0';
        let id = $this.parents('tr').data('id');
        let name = $this.parents('tr').find('.name-user').text();
        if(name == thisname){
          $("body").append('<div class="bg"></div><div class="box text-center"><p>Bạn chắc chắn muốn xóa tài khoản <strong>chính mình</strong>?</p><button class="btn btn-success ml-1 mr-1 access">Submit</button><button class="btn btn-danger ml-1 mr-1 cancel">Cancel</button></div></div>');
          admin = '1';
        }
        else{
          $("body").append('<div class="bg"></div><div class="box text-center"><p>Bạn chắc chắn muốn xóa tài khoản <strong>'+name+'</strong>?</p><button class="btn btn-success ml-1 mr-1 access">Submit</button><button class="btn btn-danger ml-1 mr-1 cancel">Cancel</button></div></div>');
        }
          $(".bg").animate({'opacity' : '1'});
          $(".bg, .cancel").click(function(){
            $(".bg").animate({'opacity' : '0'});
            $(".djsad").remove();
            setTimeout(function(){
              $(".bg,.box").remove();
            },300);
            return;
          });
          $(".access").click(function(){
            $.ajax({
                url : "./changeUser.php",
                type : "post",
                data : {
                  t : 'del',
                  admin: admin,
                  id : id
                },
                beforeSend:function(){
                  $(".bg").unbind('click');
                  $(".box").remove();
                  $(".bg").append('<div class="loading"><div class="box-loading"><div class="lds-roller"><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div></div></div></div>');
                },
                success : function (result){
                  // console.log(result);
                    let outResult = JSON.parse(result);
                    if(outResult.code == '1'){
                    if(name == thisname) window.location="../logout.php";
                    else{
                      $(".bg").empty().after('<div class="box text-center"><p style="color: #118636;font-size:28px;">DONE!</p><button class="btn btn-success cancel">Cancel</button></div>');
                      $(".cancel").click(function(){
                        $(".bg").animate({'opacity' : '0'});
                        $(".djsad").remove();
                        setTimeout(function(){
                          $(".bg,.box").remove();
                        },300);
                      });
                    }
                  }
                  else{
                    $this.find('option').removeAttr('selected');
                    $("main").append('<div class="alert alert-danger err_ajax mt-3">'+outResult.mess+'</div>');
                    setTimeout(function(){
                      $(".err_ajax").remove();
                    },5000);
                    $(".bg").remove();
                  }
                }
            });
          });
      })
      $(".changeAccess").on('change',function(){
        let $this = $(this);
        let id = $this.data('id');
        let val = $this.val();
        let admin = '0';
        let name = $this.data('name');
        if(name == thisname){
          $("body").append('<div class="bg"></div><div class="box text-center"><p>Bạn chắc chắn muốn thay đổi quyền của chính mình?</p><button class="btn btn-success ml-1 mr-1 access">Submit</button><button class="btn btn-danger ml-1 mr-1 cancel">Cancel</button></div></div>');
          admin = '1';
        }
        else{
        $("body").append('<div class="bg"></div><div class="box text-center"><p>Bạn chắc chắn muốn thay đổi quyền của <strong>'+name+'</strong>?</p><button class="btn btn-success ml-1 mr-1 access">Submit</button><button class="btn btn-danger ml-1 mr-1 cancel">Cancel</button></div></div>');
        }
        $(".bg").animate({'opacity' : '1'});
        $(".bg, .cancel").click(function(){
          $this.find('option').removeAttr('selected');
          val == '1' ? $this.find('option[value=2]').attr('selected','selected') : $this.find('option[value=1]').attr('selected','selected');
          $(".bg").animate({'opacity' : '0'});
          $(".djsad").remove();
          setTimeout(function(){
            $(".bg,.box").remove();
          },300);
          return;
        });
        $(".access").click(function(){
          $.ajax({
              url : "./changeUser.php",
              type : "post",
              data : {
                t : 'changeAccess',
                id : id,
                admin: admin,
                val : val
              },
              beforeSend:function(){
                $(".bg").unbind('click');
                $(".box").remove();
                $(".bg").append('<div class="loading"><div class="box-loading"><div class="lds-roller"><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div></div></div></div>');
              },
              success : function (result){
                // console.log(result + ' ' + id + ' ' + val);
                  let outResult = JSON.parse(result);
                  if(outResult.code == '1'){
                    if(name == thisname) window.location="../logout.php";
                    else{
                      $(".bg").empty().after('<div class="box text-center"><p style="color: #118636;font-size:28px;">DONE!</p><button class="btn btn-success cancel">Cancel</button></div>');
                      $(".cancel").click(function(){
                        $(".bg").animate({'opacity' : '0'});
                        $(".djsad").remove();
                        setTimeout(function(){
                          $(".bg,.box").remove();
                        },300);
                      });
                    }
                  }
                  else{
                    $this.find('option').removeAttr('selected');
                    val == '1' ? $this.find('option[value=2]').attr('selected','selected') : $this.find('option[value=1]').attr('selected','selected');
                    $("main").append('<div class="alert alert-danger err_ajax mt-3">'+outResult.mess+'</div>');
                    setTimeout(function(){
                      $(".err_ajax").remove();
                    },5000);
                    $(".bg").remove();
                  }
              }
          });
        });
       });
      $(".changeActive").on('click',function(){
        let $this = $(this);
        let id = $this.data('id');
        let val = $this.attr('data-act');
        let name = $this.data('name');
        let admin = '0';
        if(name == thisname){
          $("body").append('<div class="bg"></div><div class="box text-center"><p>Bạn chắc chắn muốn thay đổi quyền của chính mình?</p><button class="btn btn-success ml-1 mr-1 access">Submit</button><button class="btn btn-danger ml-1 mr-1 cancel">Cancel</button></div></div>');
          admin = '1';
        }
        else{
        $("body").append('<div class="bg"></div><div class="box text-center"><p>Bạn chắc chắn muốn thay đổi quyền của <strong>'+name+'</strong>?</p><button class="btn btn-success ml-1 mr-1 access">Submit</button><button class="btn btn-danger ml-1 mr-1 cancel">Cancel</button></div></div>');
        }
        $(".bg").animate({'opacity' : '1'});
        $(".bg, .cancel").click(function(){
          $this.find('option').removeAttr('selected');
          val == '1' ? $this.find('option[value=2]').attr('selected','selected') : $this.find('option[value=1]').attr('selected','selected');
          $(".bg").animate({'opacity' : '0'});
          $(".djsad").remove();
          setTimeout(function(){
            $(".bg,.box").remove();
          },300);
          return;
        });
        $(".access").click(function(){
          $.ajax({
              url : "./changeUser.php",
              type : "post",
              data : {
                t : 'changeActive',
                id : id,
                admin: admin,
                val : val
              },
              beforeSend:function(){
                $(".bg").unbind('click');
                $(".box").remove();
                $(".bg").append('<div class="loading"><div class="box-loading"><div class="lds-roller"><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div></div></div></div>');
              },
              success : function (result){
                // console.log(result + ' ' + id + ' ' + val);
                  let outResult = JSON.parse(result);
                  if(outResult.code == '1'){
                    if(name == thisname) window.location="../logout.php";
                    else{
                        let act = val == '1' ? '0' : '1';
                        let nm = val == '1' ? 'Block' : 'Access';
                       $this.text(nm).attr('data-act',act);
                      $("main").append('<div class="alert alert-success success_change mt-3">'+outResult.mess+'</div>');
                      setTimeout(function(){
                        $(".success_change").remove();
                      },5000);
                      $(".bg").remove();
                     
                    }
                  }
                  else{
                    $this.find('option').removeAttr('selected');
                    val == '1' ? $this.find('option[value=2]').attr('selected','selected') : $this.find('option[value=1]').attr('selected','selected');
                    $("main").append('<div class="alert alert-danger err_ajax mt-3">'+outResult.mess+'</div>');
                    setTimeout(function(){
                      $(".err_ajax").remove();
                    },5000);
                    $(".bg").remove();
                  }
              }
          });
        });
       });
    });
  </script>
</body>
</html>
