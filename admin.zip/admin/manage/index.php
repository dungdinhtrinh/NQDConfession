<?php
	if (!isset($_SESSION)) session_start();
	if(!isset($_SESSION['logined']) || !isset($_SESSION['access'])){
		$_SESSION['login_first'] = 'Trước tiên hãy đãng nhập với tư cách admin!';
		header('Location: ../login');
	}
	if($_SESSION['access'] != 'admin'){
		$_SESSION['access_error'] = "Bạn không đủ quyền truy cập trang quản trị tối cao!";
		header('Location: ../');
	}
	if(isset($_GET['page'])) $page = $_GET['page'];
	if($page == 'add'){
		include './add.php';
	}
	else if($page=='edit'){
		include './edit.php';
	}
	else{
		include './manageAccount.php';
	}
?>