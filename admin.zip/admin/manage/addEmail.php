<?php
	if(!isset($_SESSION)) session_start();

	if(!isset($_POST)){
		$_SESSION['login_first'] = 'Trước tiên hãy đãng nhập!';
		header('Location: ../login');
	}

	if(isset($_POST)){
		include '../../config/config.php';
		$id = $_POST['id'];
		$email = $_POST['email'];
		if($email == ''){
			echo json_encode(array('code' => '0', 'mess' => 'Email not define!'));
        	exit();
		}
		$sql = "SELECT * FROM account WHERE id = '".$id."'";
		$result = mysqli_query($conn, $sql);
        $verify = '0';
		if(mysqli_num_rows($result) <= 0){
        	echo json_encode(array('code' => '0', 'mess' => 'Username không tồn tại!'));
        	exit();
        }
        else{
        	while($row = mysqli_fetch_assoc($result)) {
        		if($row['access'] == 'admin' && $row['verify'] == '0'){
        			$verify = '1';
        		}
        	}
        }
        if($verify == '0'){
        	$sql_update = "UPDATE account SET email='".$email."' WHERE id='".$id."'";
        }
        else{
        	$sql_update = "UPDATE account SET email='".$email."', verify='1' WHERE id='".$id."'";
        }
        if (mysqli_query($conn, $sql_update)) {
		    echo json_encode(['code' => '1', 'mess' => 'Thay đổi đã được lưu! Hãy đăng nhập lại']);
		    exit();
		}
		else {
		    echo json_encode(['code' => '0', 'mess' => 'Error Change This User from Database!']);
		    exit();
		}
	}
	else{
		echo json_encode(['code' => '2', 'mess' => 'Lỗi hệ thống! Vui lòng liên hệ Admin để sửa lỗi!']);
		exit();
	}

?>