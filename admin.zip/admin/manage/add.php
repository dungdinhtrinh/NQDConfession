<?php
	if (!isset($_SESSION))  session_start();
?>

<!DOCTYPE html>
<html lang="vi">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>NQDConfessions</title>
    <link rel="shortcut icon" href="https://i.imgur.com/mmfPu9T.png">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link href="https://fonts.googleapis.com/css?family=Roboto+Slab&display=swap" rel="stylesheet">
	<link rel="stylesheet" href="../css/dashboard.css">
	<link rel="stylesheet" href="../css/manageAccount.css">
	<style>
		/*add page*/
		.po-re{
		    position: relative;
		}

		.po-re i{
		    position: absolute;
		    right: 13px;
		    bottom: 6px;
		    font-size: 27px;
		    color: brown;
		    cursor: pointer;
		}
	</style>
</head>
<body>

	<body>
    <nav class="navbar navbar-dark sticky-top bg-dark flex-md-nowrap p-0">
      <a class="navbar-brand col-8 col-sm-3 col-md-2 mr-0 font-weight-bold" href="../../">NQDConfessions</a>
      <ul class="navbar-nav px-3">
        <li class="nav-item text-nowrap">
          <a class="nav-link" href="../logout.php">Logout</a>
        </li>
      </ul>
    </nav>

    <div class="container-fluid">
      <div class="row">
        <nav class="col-md-2 d-none d-md-block bg-light sidebar">
          <div class="sidebar-sticky">
            <ul class="nav flex-column">
              <li class="nav-item">
                <a class="nav-link" href="../">Admin</a>
              </li>
              <li class="nav-item">
                <a class="nav-link active" href="./">Manage Account</a>
              </li>
            </ul>
          </div>
        </nav>

        <main role="main" class="col-md-10 ml-sm-auto col-lg-10 pt-3 px-4">
          <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pb-2 mb-3 border-bottom">
            <nav aria-label="breadcrumb" class="w-100">
			  <ol class="breadcrumb">
			    <li class="breadcrumb-item"><a href="../">Admin</a></li>
			    <li class="breadcrumb-item"><a href="./">Manage Account</a></li>
			    <li class="breadcrumb-item active" aria-current="page">Add New</li>
			  </ol>
			</nav>
          </div>

          <h2 class="mb-4">Add New User</h2>
          <div class="table-responsive">
			<div class="form">
				<div class="form-group">
					<label for="username">Username:</label>
					<input type="text" class="form-control" id="username" placeholder="Enter username" name="username" autocomplete="off">
				</div>
				<div class="form-group po-re">
					<label for="password">Password:</label>
					<input type="password" class="form-control" id="password" placeholder="Enter password" name="password">
					<i class="fa togg-pass fa-eye"></i>
					<i class="fa togg-pass fa-eye-slash d-none"></i>
				</div>
				<div class="form-group">
					<label>Select Access</label>
					<select class="custom-select select-access">
						<option value="1">Admin</option>
				        <option value="2" selected="selected">Supporter</option>
					</select>
				</div>
				<button type="submit" class="btn btn-primary">Submit</button>
			</div>
          </div>
        </main>
      </div>
    </div>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
	<script src="../js/autoMoreTextarea.js"></script>
	<script>
		$(document).ready(function(){
			$("#username, #password").focus(function(){
				$(this).css({'border-color' : '#ced4da'});
			});
			$(".togg-pass").click(function(){
				let cl = $(this).hasClass('fa-eye') ? 'fa-eye' : 'fa-eye-slash';
				if($(this).hasClass('fa-eye')){
					$(this).hide();
					$(".fa-eye-slash").removeClass('d-none');
					$("#password").attr('type','text');
				}
				else{
					$(this).addClass('d-none');
					$(".fa-eye").show();
					$("#password").attr('type','password');
				}
			});
			$("button[type=submit]").click(function(){
				let username = $("#username").val();
				let password = $("#password").val();
				let access = $(".select-access").val();
				if(username.trim() == ''){
					$("#username").css({'border-color' : 'red'});
					return;
				}
				if(password.trim() == ''){
					$("#password").css({'border-color' : 'red'});
					return;
				}
				$("body").append('<div class="bg"></div><div class="box text-center"><p>Bạn chắc chắn muốn thêm tài khoản <strong>'+username+'</strong>?</p><button class="btn btn-success ml-1 mr-1 access">Submit</button><button class="btn btn-danger ml-1 mr-1 cancel">Cancel</button></div></div>');
		  		$(".bg").animate({'opacity' : '1'});
		  		$(".bg, .cancel").click(function(){
		  			$(".bg").animate({'opacity' : '0'});
		  			$(".djsad").remove();
		  			setTimeout(function(){
		  				$(".bg,.box").remove();
		  			},300);
		  			return;
		  		});
		  		$(".access").click(function(){
		  			let d = new Date();
					let h = d.getHours() < 10 ? '0' : '' + d.getHours();
					let m = d.getMinutes() < 10 ? '0' : '' + d.getMinutes();
					let s = d.getSeconds() < 10 ? '0' : '' + d.getSeconds();
					let time = h + ':' + m + ":" + s;
					$.ajax({
			            url : "./changeUser.php",
			            type : "post",
			            data : {
			            	t : 'add',
			                username : username,
			                password: password,
			                access: access,
			                time : time
			            },
			            beforeSend:function(){
			            	$(".bg").unbind('click');
			            	$(".box").remove();
			            	$(".bg").append('<div class="loading"><div class="box-loading"><div class="lds-roller"><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div></div></div></div>');
			            },
			            success : function (result){
			            	// console.log(result);
			                let outResult = JSON.parse(result);
			                if(outResult.code == '1'){
			                	$(".bg").empty().after('<div class="box text-center"><p style="color: #118636;font-size:28px;">DONE!</p><button onclick="location.reload();" class="btn btn-success">Reload</button></div>');
			                }
			                else{
			                	$("main").append('<div class="alert alert-danger err_ajax mt-3">'+outResult.mess+'</div>');
			                	$("#username").val("").focus();
			                	$("#password").val("");
			                	setTimeout(function(){
			                		$(".err_ajax").remove();
			                	},3000);
			                	$(".bg").remove();
			                }
			            }
			        });
		  		});
			});
		});
	</script>
</body>
</html>
