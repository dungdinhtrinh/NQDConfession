<?php
	if(!isset($_SESSION)) session_start();
	unset($_SESSION['logined']);
	unset($_SESSION['access']);
	unset($_SESSION['em']);
	$_SESSION['login_first'] = 'Hãy đăng nhập để tiếp tục!';
	header('Location: ./login');
?>