<?php
if (!isset($_SESSION)) {
    session_start();
}

if (!isset($_SESSION['logined'])) {
    $_SESSION['login_first'] = 'Trước tiên hãy đăng nhập!';
    header('Location: ./login');
}

?>
<?php
	include '../config/config.php';
	function format_output_str($str, $smile = false){
		static $smile;
		$str = nl2br($str);
		$str = preg_replace("/([^\n\r ?&\.\/<>\"\\-]{80})/i"," \\1\n",$str);
		return $str;
	}

    $length = (int)mysqli_fetch_assoc(mysqli_query($conn, "SELECT count(id) FROM cfs"))['count(id)'];

    $limit = $length <= 15 ? $length : 15;
    $page = CEIL($length/15);

    $arr = [];
    $start = 1;
    $end = $page;

    $p = (int)$_GET['page'];
    $nextPage = $p == $page ? false : ($p + 1);
    $prevPage = $p == 1 ? false : ($p - 1);

    if($page - $p <= 6){
        $start = $page - 9;
        $end = $page;
    }
    else if($p <= 6){
        $start = 1;
        $end = 9;
    }
    else{
        $start = $p - 4;
        $end = $p + 4;
    }
    
    // echo $nextPage.' '.$prevPage;
    // exit();

    if(!isset($_GET['page']) || $p < 1 || $p > $page) header('Location: ./?page='.$page);
    $temp = ($p - 1) * $limit;
    // echo $temp . ' ' . $limit . ' ' . $length;
    // exit();
    $sql = "SELECT * FROM cfs LIMIT $temp, $limit;";

    $result = mysqli_query($conn, $sql);
    echo '<script>let lengthArr = '.$length.'</script>';
    if (mysqli_num_rows($result) > 0){
    	while($row = mysqli_fetch_assoc($result)) {
    		$active = $row['active'] == '0' ? 'No' : 'Yes';
	        $add = ['id' => $row['id'], 'stt' => $i++, 'confess' => format_output_str($row['confess']), 'active' => $active ,'time' => $row['time'],'date' => $row['date']];
	    	$arr[] = $add;
	    } 
    }
?>

<!DOCTYPE html>
<html lang="vi">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>NQDConfessions</title>
    <link rel="shortcut icon" href="https://i.imgur.com/mmfPu9T.png">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link href="https://fonts.googleapis.com/css?family=Roboto+Slab&display=swap" rel="stylesheet">
	<link rel="stylesheet" href="css/dashboard.css">
	<link rel="stylesheet" href="css/style.css">
</head>
<body>
  
    <nav class="navbar navbar-dark sticky-top bg-dark flex-md-nowrap p-0">
      <a class="navbar-brand col-8 col-sm-3 col-md-2 mr-0 font-weight-bold" href="../">NQDConfessions</a>
      <ul class="navbar-nav px-3">
        <li class="nav-item text-nowrap">
          <a class="nav-link" href="./logout.php">Logout</a>
        </li>
      </ul>
    </nav>

    <div class="container-fluid">
      <div class="row">
        <nav class="col-md-2 d-none d-md-block bg-light sidebar">
          <div class="sidebar-sticky">
            <ul class="nav flex-column">
              <li class="nav-item nav-user">
                <a class="nav-link user" href=""><?php echo strtoupper($_SESSION['logined']);?></a>
                <a class="nav-link pl-5 changePass" href="" data-name="<?php echo $_SESSION['logined'];?>">Change Password</a>
                <a class="nav-link pl-5 changeVerify" href="" data-name="<?php echo $_SESSION['logined'];?>">Edit Verify</a>
              </li>
              <?php
              if(isset($_SESSION['access']) && $_SESSION['access'] == 'admin'){
                echo ' <li class="nav-item"><a class="nav-link" href="./manage">Manage Account</a></li>';
              }
              ?>
            <!--   <li class="nav-item">
                <a class="nav-link" href="#">Orders</a>
              </li> -->
            </ul>
          </div>
        </nav>

        <main role="main" class="col-md-10 ml-sm-auto col-lg-10 pt-3 px-4">
          <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pb-2 mb-3 border-bottom">
            <nav aria-label="breadcrumb" class="w-100">
			  <ol class="breadcrumb">
			    <li class="breadcrumb-item"><a href="">Admin</a></li>
			    <li class="breadcrumb-item active" aria-current="page">Dashboard</li>
			  </ol>
			</nav>
          </div>

          <h2>Dashboard Confession</h2>
          <div class="table-responsive">
            <table class="table table-striped table-sm">
              <thead>
                <tr>
                  <th>STT</th>
                  <th>Confesstion</th>
                  <th>Posted</th>
                  <th>Time</th>
                  <th>Date</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
              	<?php
              	if(count($arr) == 0){
              		echo '<tr><td colspan="6" align="center"><div class="alert alert-primary">No Confesstion</div></td></tr>';
              	}
              	foreach ($arr as $a) {
                  // echo '<tr data-id="'.$a['id'].'"><td>'.$a['stt'].'</td><td class="dataConfess" data-toggle="tooltip" data-placement="top" title="Click to show full" >'.$a['confess'].'</td><td><button class="btn btn-success changActive" >'.$a['active'].'</button></td><td>'.$a['time'].'</td><td>'.$a['date'].'</td><td><button class="btn btn-success copy">Copy</button><button class="btn btn-danger delete" disabled="disabled">Del</button></td></tr>';
              		echo '<tr data-id="'.$a['id'].'"><td>'.$a['stt'].'</td><td class="dataConfess" data-toggle="tooltip" data-placement="top" title="Click to show full" >'.$a['confess'].'</td><td><button ';
                  echo ($a['active']=='Yes' && $_SESSION['access'] != 'admin')? 'class="btn btn-secondary changActive" disabled="disabled"' : 'class="btn btn-success changActive" ';
                  echo '>'.$a['active'].'</button></td><td>'.$a['time'].'</td><td>'.$a['date'].'</td><td><button class="btn btn-success copy">Copy</button><button class="btn btn-danger delete" disabled="disabled">Del</button></td></tr>';
              	}
              	?>
              </tbody>
            </table>
            <?php
            if(isset($_SESSION['access_error'])){
              echo '<div class="alert alert-danger" id="access_error">'.$_SESSION['access_error'].'</div>';
              echo '<script id="script">setTimeout(function(){document.getElementById("access_error").remove(document.getElementById("access_error").selectedIndex);document.getElementById("script").remove(document.getElementById("script").selectedIndex);},3000);</script>';
              unset($_SESSION['access_error']);
            }
            if(isset($_SESSION['signout_first'])){
                echo '<div class="alert alert-primary" id="signout_first">'.$_SESSION['signout_first'].'</div>';
                echo '<script id="script">setTimeout(function(){document.getElementById("signout_first").remove(document.getElementById("signout_first").selectedIndex);document.getElementById("script").remove(document.getElementById("script").selectedIndex);},3000);</script>';
                unset($_SESSION['signout_first']);
            }
            ?>
          </div>
          <?php
            if($page > 1){
              echo '<div class="d-block w-100 text-center"><ul class="pagination modal-1"><li><a ';
              echo $prevPage == false ? ' class="prev block-button"' : 'href="./?page='.$prevPage.'" class="prev"';
              echo '>«</a></li>';
              if($start > 7){
                  echo '<li> <a href="./?page=1">1</a></li>';
                  echo '<li> <a href="./?page=2">2</a></li>';
                  echo '<li> <a class="dotted block-button">...</a></li>';
              }
              for($i = $start; $i <= $end;$i++){
                if($i == $p) echo '<li><a class="block-button">'.$i.'</a></li>';
                else echo '<li> <a href="./?page='.$i.'">'.$i.'</a></li>';
              }
              if($end <= ($page - 3)){
                  echo '<li> <a class="dotted block-button">...</a></li>';
                  echo '<li> <a href="./?page='.($page-1).'">'.($page-1).'</a></li>';
                  echo '<li> <a href="./?page='.($page).'">'.($page).'</a></li>';
              }
              echo '<li><a ';
              echo $nextPage == false ? ' class="next block-button"' : 'href="./?page='.$nextPage.'" class="prev"';
              echo '>»</a></li></ul></div>';
            }
          ?>
        </main>
      </div>
    </div>


	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
	<script src="js/autoMoreTextarea.js"></script>
  <?php 
    if(isset($_SESSION['access']) && $_SESSION['access'] == 'admin'){
      echo '<script>var admin_access = true;</script>';
      echo '<script>$(".delete").removeAttr(\'disabled\');$(".delete").click(function(){let $this = $(this);let val = $this.text();let id = $this.parents("tr").data("id");$("body").append(\'<div class="bg"></div><div class="box text-center"><p>Bạn chắc chắn muốn <strong>xoá</strong> post này?</p><button class="btn btn-success ml-1 mr-1 access">Submit</button><button class="btn btn-danger ml-1 mr-1 cancel">Cancel</button></div></div>\');$(".bg").animate({\'opacity\' : \'1\'});$(".bg, .cancel").click(function(){$(".bg").animate({\'opacity\' : \'0\'});$(".djsad").remove();setTimeout(function(){$(".bg,.box").remove();},300);return;});$(".access").click(function(){$.ajax({url : "./deletePost.php",type : "post",data : {id : id},success : function (result){let outResult = JSON.parse(result);if(outResult.code == \'1\'){$this.parents(\'tr\').remove();}else{$("table").after(\'<div class="alert alert-danger">\'+outResult.mess+\'</div>\');}}});$(".bg").click();});});</script>';
    }
  ?>
  <script>
    var str = <?php echo '\''.$_SESSION['email'].'\''; ?>;
    var act = <?php echo '\''.$_SESSION['vrf'].'\''; ?>;
  </script>
  <script src="js/main.js"></script>
</body>
</html>
