<?php
	if(isset($_POST)){
		include '../config/config.php';

                $id = $_POST['id'];

                $sql = "SELECT active FROM cfs WHERE id = ".$id."";
                $result = mysqli_query($conn, $sql);
                if(mysqli_num_rows($result) == 0){
                	echo json_encode(['code' => '0', 'mess' => 'Id không tồn tại!']);
                }
                else{
                	$sql_delete = "DELETE FROM cfs WHERE id = ".$id;
                	if (mysqli_query($conn, $sql_delete)) {
        		    echo json_encode(['code' => '1', 'mess' => 'Done!']);
        		} else {
        		    echo "Xóa thất bại: " . mysqli_error($conn);
        		}
                }
	}
?>