<?php
	if(isset($_POST)){
		include '../config/config.php';

        $id = $_POST['id'];

        $sql = "SELECT active FROM cfs WHERE id = ".$id."";
        $result = mysqli_query($conn, $sql);
        if(mysqli_num_rows($result) == 0){
        	echo json_encode(['code' => '0', 'mess' => 'Id không tồn tại!']);
        }
        else{
        	while($row = mysqli_fetch_assoc($result)) {
		        $add = $row['active'] == '1' ? '0' : '1';
		        $sql_update = "UPDATE cfs SET active='".$add."' WHERE id=".$id."";
		        if (mysqli_query($conn, $sql_update)) {
				    echo json_encode(['code' => '1', 'mess' => $add == '1' ? 'Yes'  : 'No']);
				} else {
				    echo json_encode(['code' => '0', 'mess' => 'Lỗi hệ thống! Liên hệ admin để sửa chữa!']);
				}
		    }
        }
	}
?>