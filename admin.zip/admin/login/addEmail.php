<?php
if(!isset($_SESSION)) session_start();
if(isset($_SESSION['logined'])){
    $_SESSION['signout_first'] = 'Hãy đăng xuất trước khi đăng nhập lại!';
    header('Location: ../');
}
if(!isset($_SESSION['em'])){
    $_SESSION['login_first'] = 'Trước tiên hãy đăng nhập!'; 
    header('Location: ./');
}
?>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Login Admin</title>

    <!-- Font Icon -->
    <link rel="stylesheet" href="fonts/material-icon/css/material-design-iconic-font.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <link href="https://fonts.googleapis.com/css?family=Roboto+Slab&display=swap" rel="stylesheet">

    <!-- Main css -->
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

    <div class="main">
    
        <!-- Sing in  Form -->
        <section class="sign-in">
            <div class="container">
                <div class="signin-content">
                    <div class="signin-image">
                        <figure><img src="images/signin-image.jpg" alt="sing up image"></figure>
                    </div>

                    <div class="signin-form">
                        <h2 class="form-title">Login Admin</h2>
                        <?php
                        if(isset($_SESSION['error'])){
                            echo '<div class="alert alert-danger">'.$_SESSION['error'].'</div>';
                            unset($_SESSION['error']);
                        }
                        ?>
                        <form method="POST" action="" class="register-form" id="login-form">
                            <div class="alert alert-success">Cập nhật email cho ADMIN</div>
                            <div class="form-group">
                                <label for="email"><i class="zmdi zmdi-email-open"></i></label>
                                <input type="text" name="verify" id="email" class="email" placeholder="Email" autocomplete="off" />
                            </div>
                            <div class="form-group form-button">
                                <input type="submit" name="submit" id="signin" class="form-submit" value="Submit"/>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </section>
    </div>

    <!-- JS -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
    <script>
        $(document).ready(function(){
            $(".form-submit").click(function(){
                let $this = $(this);
                let email = $this.parents('form').find('.email');
                email.removeAttr('style');
                let val = email.val();
                if(val.trim() == ''){
                    email.focus();
                    return false;
                }
                $("body").append('<div class="bg"><div class="box"><div class="lds-ring"><div></div><div></div><div></div><div></div></div><div class="" style="color: white;padding-top: 20px;font-size: 24px; text-align: center; font-family: \'Roboto Slab\'">Đang thêm email cho bạn<br>Vui lòng đợi trong giây lát!</div></div></div>');
                $.ajax({
                    url : "../manage/addEmail.php",
                    type : "post",
                    data : {
                        t : 'addEmail',
                        id :  <?php echo '\''.$_SESSION['em'].'\'' ?> ,
                        email : val.trim()
                      },
                    success : function (result){
                        // console.log(result);
                        let outResult = JSON.parse(result);
                        if(outResult.code == '1'){
                            $("main,.box").empty();
                            $(".box").append('<p style="color:#28a745;font-size:24px;font-family:\'Roboto Slab\',sans-serif;">'+outResult.mess+'</p><div class="text-center"><button class="btn btn-success" onclick="window.location.assign(\'../logout.php\');">Login</button></div>');
                        }
                        else{
                            $(".bg").remove();
                            $(".email").before('<div class="alert alert-danger">'+outResult.mess+'</div>')
                        }
                    }
                });
                return false;
            });
        });
    </script>
</body><!-- This templates was made by Colorlib (https://colorlib.com) -->
</html>