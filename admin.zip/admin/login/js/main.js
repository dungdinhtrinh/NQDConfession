$(document).ready(function(){
	$("input").focus(function(){
		$(this).css({'border-bottom-color' : '#999'});
	});
	$("input[type=submit]").click(function(){
        $(".cckh1").remove();
		let username = $("input[name=username]").val();
		let password = $("input[name=password]").val();
		if(username.trim() == ''){
			$("input[name=username]").css({'border-bottom-color' : 'red'});
			return false;
		}
		if(password.trim() == ''){
			$("input[name=password]").css({'border-bottom-color' : 'red'});
			return false;
		}
		$(".error").remove();
		$("body").append('<div class="bg"><div class="box"><div class="lds-ring"><div></div><div></div><div></div><div></div></div><div class="" style="color: white;padding-top: 20px;font-size: 24px; text-align: center; font-family: \'Roboto Slab\'">Đang xác thực tài khoản của bạn<br>Vui lòng đợi trong giây lát!</div></div></div>');
		$.ajax({
            url : "./checkLogin.php",
            type : "post",
            data : {
                 username : username,
                 password : password
            },
            success : function (result){
                // console.log(result);
                let outResult = JSON.parse(result);
                if(outResult.code == '1'){
                    if(outResult.head == 'admin') window.location="../";
                    else if(outResult.head == 'email') window.location="./verify.php?tt=2";
                	else window.location="./verify.php?tt=1";
                }
                else if(outResult.code == '2'){
                    $(".bg").remove();
                    $("input[name=username]").val('');
                    $("input[name=password]").val('');
                    $("#login-form").before('<div class="alert alert-primary cckh1">'+outResult.mess+'</div>');
                }
                else{
                	$(".bg").remove();
                	$('.' + outResult.class1).val('').css({'border-bottom-color' : 'red'});
                    $('.' + outResult.class2).val('').css({'border-bottom-color' : 'red'});
                	$("label[for=" + outResult.class1 + ']').before('<div class="error">' + outResult.mess + '</div>');
                }
            }
        });
		return false;
	})
});