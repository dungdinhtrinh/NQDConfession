<?php

    if(!isset($_SESSION)) session_start();
    if($_GET['tt'] == '1'){
        include './checkPassVerify.php';
    }
    else if($_GET['tt'] == '2'){
        include './addEmail.php';
    }
    else header('Location: ./');
?>