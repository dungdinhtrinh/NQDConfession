<?php
if(!isset($_SESSION)) session_start();
if(isset($_SESSION['logined'])){
    $_SESSION['signout_first'] = 'Hãy đăng xuất trước khi đăng nhập lại!';
    header('Location: ../');
}
if(!isset($_SESSION['verify'])){
	$_SESSION['login_first'] = 'Trước tiên hãy đăng nhập!';	
    header('Location: ./');
}
if(isset($_POST['submit'])){
	$code = $_POST['verify'];
	if($code == $_SESSION['verify']['verify']){
		$_SESSION['access'] = $_SESSION['verify']['access'];
	    $_SESSION['logined'] = $_SESSION['verify']['logined'];
        $_SESSION['email'] = $_SESSION['verify']['email'];
        $_SESSION['vrf'] = $_SESSION['verify']['vrf'];
	    unset($_SESSION['verify']);
		header('Location: ../');
	}
	else{
		$_SESSION['error'] = 'Mã xác nhận không chính xác!';
	}
}
?>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Login Admin</title>

    <!-- Font Icon -->
    <link rel="stylesheet" href="fonts/material-icon/css/material-design-iconic-font.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <link href="https://fonts.googleapis.com/css?family=Roboto+Slab&display=swap" rel="stylesheet">

    <!-- Main css -->
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

    <div class="main">
    
        <!-- Sing in  Form -->
        <section class="sign-in">
            <div class="container">
                <div class="signin-content">
                    <div class="signin-image">
                        <figure><img src="images/signin-image.jpg" alt="sing up image"></figure>
                    </div>

                    <div class="signin-form">
                        <h2 class="form-title">Login Admin</h2>
                        <?php
                        if(isset($_SESSION['error'])){
                            echo '<div class="alert alert-danger">'.$_SESSION['error'].'</div>';
                            unset($_SESSION['error']);
                        }
                        if(isset($_SESSION['check_email'])){
                            echo '<div class="alert alert-primary">'.$_SESSION['check_email'].'</div>';
                            unset($_SESSION['check_email']);
                        }
                        ?>
                        <form method="POST" action="" class="register-form" id="login-form">
                            <div class="form-group">
                                <label for="verify"><i class="zmdi zmdi-lock"></i></label>
                                <input type="text" name="verify" id="verify" class="verify" placeholder="Mã xác nhận" autocomplete="off"/>
                            </div>
                            <div class="form-group form-button">
                                <input type="submit" name="submit" id="signin" class="form-submit" value="Submit"/>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </section>

    </div>
</body>
</html>