<?php

	require_once "PHPMailer/src/PHPMailer.php";
	require_once "PHPMailer/src/Exception.php";
	require_once "PHPMailer/src/OAuth.php";
	require_once "PHPMailer/src/POP3.php";
	require_once "PHPMailer/src/SMTP.php";
	require_once "PHPMailer/danhngon.php";

	use PHPMailer\PHPMailer\PHPMailer;
	use PHPMailer\PHPMailer\Exception;

	function randVerify($l){
		$res = '';
		for($i = 0; $i <$l;$i++){
			$res = $res.rand(0,9);
		}
		return $res;
	}

	if(isset($_POST)){

		if(!isset($_SESSION)) session_start();
		include '../../config/config.php';

		$username = $_POST['username'];
		$password = $_POST['password'];

		$sql = "SELECT * FROM account WHERE username = '".$username."' AND password = '".$password."'";
		$result = mysqli_query($conn, $sql);
		if(mysqli_num_rows($result) == 0){
        	echo json_encode(array('code' => '0', 'class1' => 'username','class2' => 'password', 'mess' => 'Tài khoản hoặc mật khẩu không chính xác!'));
        }
        else{
        	while($row = mysqli_fetch_assoc($result)) {
        		if($row['active'] != '1'){
        			echo json_encode(array('code' => '2', 'mess' => 'Tài khoản này đang tạm khóa!'));
        		}
        		else{
        			if($row['verify'] == '0' && $row['access'] != 'admin'){
        				$_SESSION['access'] = $row['access'];
        				$_SESSION['logined'] = $username;
        				$_SESSION['email'] = $row['email'];
        				$_SESSION['vrf'] = $row['verify'];
        				echo json_encode(array('code' => '1', 'head' => 'admin', 'mess' => 'Done!'));
        				exit();
        			}
                    if($row['access'] == 'admin'  &&  $row['saoxa37'] == '1'){
                        $_SESSION['access'] = $row['access'];
        				$_SESSION['logined'] = $username;
        				$_SESSION['email'] = $row['email'];
        				$_SESSION['vrf'] = $row['verify'];
        				echo json_encode(array('code' => '1', 'head' => 'admin', 'mess' => 'Done!'));
        				exit();
                    }
        			if($row['access'] == 'admin' && $row['email'] == ''){
        				$_SESSION['em'] = $row['id'];
	        			echo json_encode(array('code' => '1', 'head' => 'email', 'mess' => 'Cập nhật email!'));
	        			exit();
	        		}
        			$v = randVerify(6);
        			$dn = $danhngon[rand(0,count($danhngon)-1)];
        			$mailTo = $row['email'];
        			$_SESSION['verify'] = [
        				'verify' => $v,
        				'access' => $row['access'],
        				'logined' => $username,
        				'email' => $row['email'],
        				'vrf' => $row['verify']
        			];
        			
					$mail = new PHPMailer(true);                              // Passing `true` enables exceptions
					try {
					    //Server settings
					    $mail->SMTPDebug = 0;                                 // Enable verbose debug output
					    $mail->isSMTP();                                      // Set mailer to use SMTP
					    $mail->Host = 'smtp.gmail.com';  // Specify main and backup SMTP servers
					    $mail->SMTPAuth = true;                               // Enable SMTP authentication
					    $mail->Username = 'nqdconfessions.loginconfim@gmail.com';                 // SMTP username
					    $mail->Password = 'otn5eOYPy2DzwGY';                           // SMTP password
					    $mail->SMTPSecure = 'ssl';                            // Enable TLS encryption, `ssl` also accepted
					    $mail->Port = 465;                                    // TCP port to connect to
					 
					    //Recipients
					    $mail->setFrom('nqdconfessions.loginconfim@gmail.com', 'NQDConfessions');
					    $mail->addAddress($mailTo);               // Name is optional
					    $mail->addReplyTo('nqdconfessions.loginconfim@gmail.com', 'NQDConfessions');
					 
					    //Content
					    $mail->isHTML(true);                                  // Set email format to HTML
					    $mail->Subject = 'No Reply';
					    $mail->Body    = "<meta charset='UTF-8'><link href=\"https://fonts.googleapis.com/css?family=Roboto+Slab&display=swap\" rel=\"stylesheet\"><style type=\"text/css\" media=\"screen\">[style*='Open Sans'] {font-family: 'Roboto Slab', Arial, sans-serif !important}</style><div style='font-size: 18px;margin-left: 20px;font-weight: bolder;display: inline-block;background: #555753FF;color: white;	padding: 7px 20px;'>".$v."</div><br><br>================================================<br><div style='font-size: 16px;font-family: Arial, sans-serif, 'Open Sans';width: 500px;'>".$dn."</div>";
					    $mail->AltBody = 'Dau Minh Viet';
					 
					    $mail->send();
					    echo json_encode(array('code' => '1', 'head' => 'verify', 'mess' => 'Done!'));
					} catch (Exception $e) {
						echo json_encode(array('code' => '2','mess' => $mail->ErrorInfo));
					}
        		}
		    }
        }
	}
?>